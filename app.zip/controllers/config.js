module.exports = {
    serviceID: "SIDVA301e6c50c6ca9b8f2bb20ca5a61e443c",
    accountSID: "AC579d3e39682aa9ef52ef5728d0d12707",
    authToken: "fda3eb8440545dcbf591833cb72d6547",
    urlforTesting: "",
    urlforDevelopement: ""
}
// AC579d3e39682aa9ef52ef5728d0d12707
// fda3eb8440545dcbf591833cb72d6547
// AC579d3e39682aa9ef52ef5728d0d1270


// SERVICE SIDVA301e6c50c6ca9b8f2bb20ca5a61e443c
