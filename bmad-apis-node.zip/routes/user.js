var express = require('express');
var Router = express.Router();
var userController = require('../controllers/user_controller');

var router = function(){

    Router.post('/follow', userController.follow);
    Router.post('/unfollow', userController.unfollow);
    Router.get('/followrequestacpt', userController.followrequestacpt);
    Router.put('/followrequestrej', userController.followrequestrej);
    Router.get('/getfollowers', userController.getfollowers);
    Router.post('/userlike', userController.Userlike);
    Router.post('/userunlike', userController.UserUnlike);

    

    Router.get('/userstatus', userController.Userstatus);
    Router.post('/likecount', userController.likecount);
    return Router
}

module.exports = router();